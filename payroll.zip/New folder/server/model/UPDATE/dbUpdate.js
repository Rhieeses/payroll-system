const connection = require('../../config/db');

async function updateAttendance(attendanceUpdate) {
	const { attendanceId, timeInUTC, timeOutUTC } = attendanceUpdate;

	const insertQuery = `UPDATE attendance
        SET time_in = $1,
        time_out = $2
        WHERE id = $3;`;

	try {
		await connection.query(insertQuery, [timeInUTC, timeOutUTC, attendanceId]);
	} catch (error) {
		console.error(`Error updating attendance: ${error.message}`);
		throw new Error(`Error updating attendance: ${error.message}`);
	}
}

module.exports = {
	updateAttendance,
};
