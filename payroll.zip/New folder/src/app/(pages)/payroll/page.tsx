import Layout from '@/components/custom-ui/layout';
import {
	Table,
	TableBody,
	TableCaption,
	TableCell,
	TableFooter,
	TableHead,
	TableHeader,
	TableRow,
} from '@/components/ui/table';

const employeeAttendance = [
	{
		id: 1,
		name: 'John Doe',
		payPerHour: 20,
		workHours: 40,
		overtimeHours: 5,
	},
	{
		id: 2,
		name: 'Jane Smith',
		payPerHour: 25,
		workHours: 45,
		overtimeHours: 10,
	},
	{
		id: 3,
		name: 'Mark Johnson',
		payPerHour: 18,
		workHours: 30,
		overtimeHours: 0,
	},
	{
		id: 4,
		name: 'Lucy Brown',
		payPerHour: 22,
		workHours: 38,
		overtimeHours: 2,
	},
];

export default function Payroll() {
	const calculateTotalPay = (workHours: number, overtimeHours: number, payPerHour: number) => {
		const overtimeRate = 1.5; // Assume overtime is paid at 1.5x the rate
		return workHours * payPerHour + overtimeHours * payPerHour * overtimeRate;
	};
	return (
		<Layout>
			<>
				<span className='flex items-center gap-2'>
					<i className='bx bx-chevron-left light-border rounded-md p-1'></i>
					<p className='label'>November 23, 2024</p>
					<i className='bx bx-chevron-right light-border rounded-md p-1'></i>
				</span>

				<Table className=''>
					<TableCaption>Employee Payroll List</TableCaption>
					<TableHeader>
						<TableRow>
							<TableHead className='w-[100px]'>No.</TableHead>
							<TableHead>Employee Name</TableHead>
							<TableHead>Pay/Hour</TableHead>
							<TableHead>Total Hours</TableHead>
							<TableHead>Overtime Hours</TableHead>
							<TableHead className='text-right'>Total Pay</TableHead>
						</TableRow>
					</TableHeader>
					<TableBody>
						{employeeAttendance.map((employee) => (
							<TableRow key={employee.id}>
								<TableCell className='font-medium'>{employee.id}</TableCell>
								<TableCell>{employee.name}</TableCell>
								<TableCell>${employee.payPerHour.toFixed(2)}</TableCell>
								<TableCell>{employee.workHours}</TableCell>
								<TableCell>{employee.overtimeHours}</TableCell>
								<TableCell className='text-right'>
									$
									{calculateTotalPay(
										employee.workHours,
										employee.overtimeHours,
										employee.payPerHour,
									).toFixed(2)}
								</TableCell>
							</TableRow>
						))}
					</TableBody>
					<TableFooter>
						<TableRow>
							<TableCell
								colSpan={5}
								className='font-medium'>
								Grand Total
							</TableCell>
							<TableCell className='text-right'>
								$
								{employeeAttendance
									.reduce(
										(total, employee) =>
											total +
											calculateTotalPay(
												employee.workHours,
												employee.overtimeHours,
												employee.payPerHour,
											),
										0,
									)
									.toFixed(2)}
							</TableCell>
						</TableRow>
					</TableFooter>
				</Table>
			</>
		</Layout>
	);
}
