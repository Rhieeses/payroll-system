'use client';
import axios from 'axios';
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { TimeInput } from '@nextui-org/date-input';
import { parseAbsoluteToLocal } from '@internationalized/date';
import { useToast } from '@/hooks/use-toast';

type TimeFormProps = {
	rowId: string | null;
	attendanceId: string | null;
	rowTimeIn: string | null;
	rowTimeOut: string | null;

	refetch: () => void;
};

function parseTimeOrNull(value: any): any {
	if (value) {
		return parseAbsoluteToLocal(value);
	}
	return null;
}

const calculateTimeDifference = (timeIn: any, timeOut: any) => {
	if (!timeIn || !timeOut) {
		console.error('TimeIn or TimeOut is null or undefined');
		return null;
	}

	try {
		const timeInMilliseconds =
			timeIn.hour * 3600000 +
			timeIn.minute * 60000 +
			timeIn.second * 1000 +
			timeIn.millisecond;
		const timeOutMilliseconds =
			timeOut.hour * 3600000 +
			timeOut.minute * 60000 +
			timeOut.second * 1000 +
			timeOut.millisecond;

		const diffInMilliseconds = timeOutMilliseconds - timeInMilliseconds;

		if (diffInMilliseconds < 0) {
			return 'time-out cannot be earlier than time in';
		}

		const diffInHours = diffInMilliseconds / (1000 * 60 * 60);

		return diffInHours.toFixed(2);
	} catch (error) {
		console.error('Error calculating time difference:', error);
		return null;
	}
};

export default function TimeForm({
	rowId,
	attendanceId,
	rowTimeIn,

	rowTimeOut,
	refetch,
}: TimeFormProps) {
	const { toast } = useToast();
	const [timeIn, setTimeIn] = useState(parseTimeOrNull(rowTimeIn));
	const [timeOut, setTimeOut] = useState(parseTimeOrNull(rowTimeOut));
	const [loading, setLoading] = useState(false);

	const parsedTime = parseTimeOrNull(rowTimeIn);
	const timeStringRow = parsedTime ? `${parsedTime.hour}:${parsedTime.minute}` : '';
	const timeStringRowInput = timeIn ? `${timeIn.hour}:${timeIn.minute}` : '';

	const formEdit = async (event: React.FormEvent) => {
		event.preventDefault();
		setLoading(true);

		const timeInUTC = new Date(
			Date.UTC(
				timeIn.year,
				timeIn.month - 1, // month is 0-based
				timeIn.day,
				timeIn.hour,
				timeIn.minute,
				timeIn.second,
				timeIn.millisecond,
			),
		).toISOString();

		const timeOutUTC = new Date(
			Date.UTC(
				timeOut.year,
				timeOut.month - 1, // month is 0-based
				timeOut.day,
				timeOut.hour,
				timeOut.minute,
				timeOut.second,
				timeOut.millisecond,
			),
		).toISOString();

		try {
			const response = await axios.patch(
				'/api/attendance-edit',
				{
					attendanceId,
					timeInUTC,
					timeOutUTC,
				},
				{ withCredentials: true },
			);
			if (response.status === 200) {
				toast({
					title: 'Employee Attendance Updated',
					description: 'Employee Time In/out Updated.',
				});
			}
		} catch (error: any) {
			console.error('An error occurred:', error.message || error);
		} finally {
			refetch();
			setLoading(false);
		}
	};

	const formSubmit = async (event: React.FormEvent) => {
		event.preventDefault();

		const now = new Date();
		const year = now.getFullYear();
		const month = now.getMonth();
		const day = now.getDate();

		const timeInUTC = new Date(
			Date.UTC(
				year,
				month,
				day,
				timeIn.hour,
				timeIn.minute,
				timeIn.second,
				timeIn.millisecond,
			),
		).toISOString();

		const timeOutUTC = new Date(
			Date.UTC(
				year,
				month,
				day,
				timeOut.hour,
				timeOut.minute,
				timeOut.second,
				timeOut.millisecond,
			),
		).toISOString();

		try {
			const response = await axios.post('/api/employee-attendance', {
				rowId,
				timeInUTC,
				timeOutUTC,
			});
			if (response.status === 200) {
				toast({
					title: 'New Employee Timestamp Added',
					description: 'Employee Time In/out inserted.',
				});
			}
		} catch (error: any) {
			console.error('An error occurred:', error.message || error);
		} finally {
			setLoading(false);
		}
	};

	return (
		<div className='flex justify-between items-center justify-start'>
			<div className='flex flex-col w-1/2'>
				<div className='flex gap-2'>
					<TimeInput
						classNames={{ base: 'light-border rounded-xl', input: 'space-x-1' }}
						label='Time in'
						startContent={<i className='bx bx-time flex-shrink-0 mr-[1rem]'></i>}
						hourCycle={12}
						hideTimeZone
						isRequired
						value={timeIn}
						onChange={setTimeIn}
					/>

					<TimeInput
						classNames={{ base: 'light-border rounded-xl', input: 'space-x-1' }}
						label='Time out'
						startContent={<i className='bx bx-time flex-shrink-0 mr-[1rem]'></i>}
						hourCycle={12}
						hideTimeZone
						value={timeOut}
						onChange={setTimeOut}
					/>
				</div>

				<span className='text-default-500 text-sm label'>
					<p>
						Total Hours Worked:{' '}
						{timeIn && timeOut
							? calculateTimeDifference(timeIn, timeOut)
							: 'Please enter both times'}
					</p>
				</span>
			</div>

			{attendanceId ? (
				<Button
					onClick={formEdit}
					disabled={timeStringRow === timeStringRowInput || !timeStringRowInput}
					className='p-5'>
					Edit Attendance
				</Button>
			) : (
				<Button
					onClick={formSubmit}
					disabled={timeOut && timeOut.hour === null}
					className='p-5'>
					Insert Attendance
				</Button>
			)}
		</div>
	);
}

/**
 * 
 * {attendanceId ? (
				<Button
					onClick={formEdit}
					disabled={timeStringRow === timeStringRowInput || !timeStringRowInput}
					className='p-5'>
					Edit Attendance
				</Button>
			) : (
				<Button
					onClick={formSubmit}
					disabled={timeOut && timeOut.hour === null}
					className='p-5'>
					Insert Attendance
				</Button>
			)}
 */
