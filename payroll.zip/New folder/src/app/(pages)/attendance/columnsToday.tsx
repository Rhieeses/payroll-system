'use client';
import { useEffect, useState, useCallback } from 'react';
import { ColumnDef } from '@tanstack/react-table';
import { Checkbox } from '@/components/ui/checkbox';
import { ArrowUpDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { AttendanceSchema } from './columns';
import TimeForm from './timeForm';
import { TimeToday } from '@/components/utils/functions/time';
import { useToast } from '@/hooks/use-toast';
import {
	Select,
	SelectContent,
	SelectGroup,
	SelectItem,
	SelectTrigger,
	SelectValue,
} from '@/components/ui/select';
import { parseAbsoluteToLocal, Time } from '@internationalized/date';
import { TimeInput } from '@nextui-org/date-input';
import axios from 'axios';

interface TimeProps {
	[key: string]: any;
}

function parseTimeOrNull(value: any): any {
	if (value) {
		return parseAbsoluteToLocal(value);
	}
	return null;
}

export const columnsToday = (refetch: () => void): ColumnDef<AttendanceSchema>[] => {
	const [rowData, setRowData] = useState<{
		[key: string]: {
			status: string;
			timeIn: TimeProps;
			timeOut: TimeProps;
		};
	}>({});

	const handleStatusChange = (rowId: string, status: string) => {
		setRowData((prev) => ({
			...prev,
			[rowId]: {
				...prev[rowId],
				status,
			},
		}));
	};

	const handleTimeIn = (rowId: string, timeIn: TimeProps) => {
		setRowData((prev) => ({
			...prev,
			[rowId]: {
				...prev[rowId],
				timeIn,
			},
		}));
	};

	const handleTimeOut = (rowId: string, timeOut: TimeProps) => {
		setRowData((prev) => ({
			...prev,
			[rowId]: {
				...prev[rowId],
				timeOut,
			},
		}));
	};

	const { toast } = useToast();
	//const [timeIn, setTimeIn] = useState<TimeProps>({});
	//const [timeOut, setTimeOut] = useState<TimeProps>({});
	const [loading, setLoading] = useState(false);

	const formEdit = async (rowId: string, attendanceId: string) => {
		setLoading(true);

		console.log();
		const timeInRow = rowData[rowId].timeIn;
		const timeOutRow = rowData[rowId].timeOut;

		const timeInUTC = new Date(
			Date.UTC(
				timeInRow.year,
				timeInRow.month - 1, // month is 0-based
				timeInRow.day,
				timeInRow.hour,
				timeInRow.minute,
				timeInRow.second,
				timeInRow.millisecond,
			),
		).toISOString();

		const timeOutUTC = new Date(
			Date.UTC(
				timeOutRow.year,
				timeOutRow.month - 1, // month is 0-based
				timeOutRow.day,
				timeOutRow.hour,
				timeOutRow.minute,
				timeOutRow.second,
				timeOutRow.millisecond,
			),
		).toISOString();

		try {
			const response = await axios.patch(
				'/api/attendance-edit',
				{
					attendanceId,
					timeInUTC,
					timeOutUTC,
				},
				{ withCredentials: true },
			);
			if (response.status === 200) {
				toast({
					title: 'Employee Attendance Updated',
					description: 'Employee Time In/out Updated.',
				});
			}
		} catch (error: any) {
			console.error('An error occurred:', error.message || error);
		} finally {
			refetch();
			setLoading(false);
		}
	};

	const formSubmit = async (rowId: string) => {
		const now = new Date();
		const year = now.getFullYear();
		const month = now.getMonth();
		const day = now.getDate();

		const timeInRow = rowData[rowId].timeIn;
		const timeOutRow = rowData[rowId].timeOut;

		const timeInUTC = new Date(
			Date.UTC(
				year,
				month,
				day,
				timeInRow.hour,
				timeInRow.minute,
				timeInRow.second,
				timeInRow.millisecond,
			),
		).toISOString();

		const timeOutUTC = new Date(
			Date.UTC(
				year,
				month,
				day,
				timeOutRow.hour,
				timeOutRow.minute,
				timeOutRow.second,
				timeOutRow.millisecond,
			),
		).toISOString();

		try {
			const response = await axios.post('/api/employee-attendance', {
				rowId,
				timeInUTC,
				timeOutUTC,
			});
			if (response.status === 200) {
				toast({
					title: 'New Employee Timestamp Added',
					description: 'Employee Time In/out inserted.',
				});
			}
		} catch (error: any) {
			console.error('An error occurred:', error.message || error);
		} finally {
			setLoading(false);
		}
	};
	return [
		{
			id: 'select',
			header: ({ table }) => (
				<Checkbox
					checked={
						table.getIsAllPageRowsSelected() ||
						(table.getIsSomePageRowsSelected() && 'indeterminate')
					}
					onCheckedChange={(value) => table.toggleAllPageRowsSelected(!!value)}
					aria-label='Select all'
				/>
			),
			cell: ({ row }) => (
				<Checkbox
					checked={row.getIsSelected()}
					onCheckedChange={(value) => row.toggleSelected(!!value)}
					aria-label='Select row'
				/>
			),
			enableSorting: false,
			enableHiding: false,
		},

		{
			accessorKey: 'employee_name',
			header: ({ column }) => {
				return (
					<Button
						className='p-0'
						variant='ghost'
						onClick={() => column.toggleSorting(column.getIsSorted() === 'asc')}>
						Name
						<ArrowUpDown />
					</Button>
				);
			},
			cell: ({ row }) => <div className='capitalize'>{row.getValue('employee_name')}</div>,
		},
		{
			accessorKey: 'position',
			header: 'Position',
			cell: ({ row }) => <div className='capitalize'>{row.getValue('position')}</div>,
		},

		{
			accessorKey: 'department',
			header: 'Department',
			cell: ({ row }) => <div className='capitalize'>{row.getValue('department')}</div>,
		},

		{
			accessorKey: 'total_hours',
			header: 'Total Hours',
			cell: ({ row }) => (
				<div className='flex gap-2 capitalize'>
					<p>{row.getValue('total_hours')}</p>
					<p className='label'>Hours</p>
				</div>
			),
		},

		{
			accessorKey: 'overtime',
			header: 'Overtime Hours',
			cell: ({ row }) => (
				<div className='flex gap-2 capitalize'>
					<p>{row.getValue('overtime')}</p>
					<p className='label'>Hours</p>
				</div>
			),
		},

		{
			accessorKey: 'TimeToday',
			header: TimeToday,
			cell: ({ row }: any) => {
				const { id, time_in, time_out } = row.original;
				const currentTimeIn: any = rowData[id]?.timeIn || parseTimeOrNull(time_in);
				const currentTimeOut: any = rowData[id]?.timeOut || parseTimeOrNull(time_out);

				return (
					<div className='flex justify-between items-center justify-start'>
						<div className='flex flex-col w-1/2'>
							<div className='flex gap-2'>
								<TimeInput
									classNames={{
										base: 'light-border rounded-xl',
										input: 'space-x-1',
										segment: 'focus:bg-gray-300 p-1',
									}}
									label='Time in'
									startContent={
										<i className='bx bx-time flex-shrink-0 mr-[1rem]'></i>
									}
									hourCycle={12}
									hideTimeZone
									isRequired
									value={currentTimeIn}
									onChange={(value) => handleTimeIn(id, value)}
								/>

								<TimeInput
									classNames={{
										base: 'light-border rounded-xl',
										input: 'space-x-1',
									}}
									label='Time out'
									startContent={
										<i className='bx bx-time flex-shrink-0 mr-[1rem]'></i>
									}
									hourCycle={12}
									hideTimeZone
									value={currentTimeOut}
									onChange={(value) => handleTimeOut(id, value)}
								/>
							</div>
						</div>
					</div>
				);
			},
		},

		{
			accessorKey: 'status',
			header: 'Status',
			cell: ({ row }: any) => {
				const { id } = row.original;
				const currentStatus: any = rowData[id]?.status || '';

				return (
					<div>
						<Select
							value={currentStatus}
							onValueChange={(status) => handleStatusChange(id, status)}>
							<SelectTrigger className='w-[180px]'>
								<SelectValue placeholder='Status' />
							</SelectTrigger>
							<SelectContent>
								<SelectGroup>
									<SelectItem value='absent'>Absent</SelectItem>
									<SelectItem value='present'>Present</SelectItem>
									<SelectItem value='grapes'>Late</SelectItem>
									<SelectItem value='leave'>Leave</SelectItem>
								</SelectGroup>
							</SelectContent>
						</Select>
					</div>
				);
			},
		},

		{
			accessorKey: 'actions',
			header: 'Actions',
			cell: ({ row }: any) => {
				const rowId = row.original.id;
				const timeIn = row.original.time_in;
				const attendanceId = row.original.attendance_id;

				const parsedTime = parseTimeOrNull(timeIn);
				const timeStringRow = parsedTime ? `${parsedTime.hour}:${parsedTime.minute}` : '';
				const timeStringRowInput = rowData[rowId]?.timeIn
					? `${rowData[rowId]?.timeIn.hour}:${rowData[rowId]?.timeIn.minute}`
					: '';

				return (
					<div>
						{attendanceId ? (
							<Button
								className='p-5'
								disabled={
									timeStringRow === timeStringRowInput || !rowData[rowId]?.timeIn
								}
								onClick={() => formEdit(rowId, timeStringRowInput)}>
								Edit Attendance
							</Button>
						) : (
							<Button
								className='p-5'
								onClick={() => formSubmit(rowId)}>
								Insert Attendance
							</Button>
						)}
					</div>
				);
			},
		},
	];
};

/**

		
 * <div>
					{attendance_id ? (
						<Button
							className='p-5'
							onClick={() => {
								<TimeForm
									refetch={refetch}
									attendanceId={attendance_id}
									rowTimeIn={time_in}
									rowTimeOut={time_out}
									rowId={id}
								/>;
							}}>
							Edit Attendance
						</Button>
					) : (
						<Button
							className='p-5'
							onClick={() => {
								<TimeForm
									refetch={refetch}
									attendanceId={null}
									rowTimeIn={time_in}
									rowTimeOut={time_out}
									rowId={id}
								/>;
							}}>
							Insert Attendance
						</Button>
					)}
				</div>
 */
