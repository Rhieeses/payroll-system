'use client';
import { useState, useEffect } from 'react';
import axios from 'axios';

export const useAttendance = () => {
	const [attendanceDaily, setAttendanceDaily] = useState([]);
	const [attendanceWeekly, setAttendanceWeekly] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);

	const fetchAttendanceDaily = async () => {
		setLoading(true);

		try {
			const attendanceResponse = await axios.get('/api/attendance-daily', {
				withCredentials: true,
			});

			setAttendanceDaily(attendanceResponse.data);
		} catch (err: any) {
			console.error('Error fetching attendance data:', err);
			setError(err.response?.data?.error || 'An error occurred');
		} finally {
			setLoading(false);
		}
	};

	const fetchAttendanceWeekly = async () => {
		setLoading(true);
		try {
			const attendanceResponse = await axios.get('/api/attendance-weekly', {
				withCredentials: true,
			});

			setAttendanceWeekly(attendanceResponse.data);
		} catch (err: any) {
			console.error('Error fetching attendance data:', err);
			setError(err.response?.data?.error || 'An error occurred');
		} finally {
			setLoading(false);
		}
	};

	useEffect(() => {
		fetchAttendanceDaily();
		fetchAttendanceWeekly();
	}, []);

	return {
		attendanceDaily,
		attendanceWeekly,
		loading,
		error,
		refetch: fetchAttendanceDaily,
		fetchAttendanceWeekly,
	};
};
